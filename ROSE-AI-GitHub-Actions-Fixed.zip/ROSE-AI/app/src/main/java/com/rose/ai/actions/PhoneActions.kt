package com.rose.ai.actions

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import java.util.Locale

/** Safe, user-confirmed phone actions. None of these send messages, buy things or delete data. */
sealed interface PhoneAction {
    object OpenSettings : PhoneAction
    object OpenCamera : PhoneAction
    object OpenCalculator : PhoneAction
    object OpenYouTube : PhoneAction
    data class SearchYouTube(val query: String) : PhoneAction
    data class OpenWebsite(val url: String) : PhoneAction
    data class OpenApp(val label: String) : PhoneAction

    fun describe(): String = when (this) {
        OpenSettings -> "Open the Android Settings"
        OpenCamera -> "Open the Camera"
        OpenCalculator -> "Open the Calculator"
        OpenYouTube -> "Open YouTube"
        is SearchYouTube -> "Search YouTube for \"$query\""
        is OpenWebsite -> "Open the website $url"
        is OpenApp -> "Open the app \"$label\""
    }
}

/** Understands simple English / Banglish / Bengali commands. Returns null for normal chat. */
object PhoneActionParser {

    private const val YT_SUFFIX = """(?:\s*(?:e|te|এ|ে))?"""
    private const val SEARCH_WORD = """(?:search|serach|সার্চ|খুঁজ\S*|khoj\S*|khuj\S*)"""

    private val youtubePatterns = listOf(
        Regex("""^(?:open|launch)\s+youtube\s+(?:and\s+)?(?:search|find|play)\s+(?:for\s+)?(.+)$"""),
        Regex("""^(?:search|find|play|watch)\s+(?:for\s+)?(.+?)\s+(?:on|in)\s+youtube.*$"""),
        Regex("""^(?:search|find)\s+youtube\s+(?:for\s+)?(.+)$"""),
        Regex("""^youtube\s+search\s+(?:for\s+)?(.+)$"""),
        Regex("""^(?:youtube|ইউটিউব)$YT_SUFFIX\s+$SEARCH_WORD\s+(?:for\s+)?(.+)$"""),
        Regex("""^(.+?)\s+(?:youtube|ইউটিউব)$YT_SUFFIX\s+(?:$SEARCH_WORD|dekhao|দেখাও).*$""")
    )

    private val openPrefix = Regex("""^(?:open|launch)\s+(?:the\s+)?(?:app\s+)?(.+)$""")
    private val openSuffix = Regex(
        """^(.+?)\s+(?:open|khulo|kholo|khul|khol|chalu|খোলো|খুলো|খোল|ওপেন|চালু)(?:\s+(?:koro|kor|করো|কর|dao|দাও))?$"""
    )
    private val domainRegex =
        Regex("""^(?:https?://)?(?:www\.)?[a-z0-9-]+(?:\.[a-z0-9-]+)*\.[a-z]{2,}(?:[/?#]\S*)?$""")
    private val greetingPrefix = Regex("""^(?:hey |hi |ok |okay )?(?:rose[, ]+)?(?:please |plz )?""")
    private val queryTail = Regex("""\s+(?:koro|kor|করো|কর|please|plz|dao|দাও)$""")

    fun parse(input: String): PhoneAction? {
        val text = input.trim().lowercase(Locale.ROOT)
            .trimEnd('.', '!', '?', '।')
            .replace(Regex("\\s+"), " ")
        if (text.isEmpty() || text.split(" ").size > 12) return null
        val stripped = text.replace(greetingPrefix, "")

        for (pattern in youtubePatterns) {
            val q = pattern.find(stripped)?.groupValues?.get(1)?.replace(queryTail, "")?.trim()
            if (!q.isNullOrBlank()) return PhoneAction.SearchYouTube(q)
        }

        val target = (openPrefix.find(stripped)?.groupValues?.get(1)
            ?: openSuffix.find(stripped)?.groupValues?.get(1))
            ?.removePrefix("website ")?.removePrefix("site ")?.removePrefix("ওয়েবসাইট ")
            ?.trim()
            ?: return null
        return resolveTarget(target)
    }

    private fun resolveTarget(t: String): PhoneAction? = when {
        t.isEmpty() -> null
        t.contains("setting") || t.contains("সেটিং") -> PhoneAction.OpenSettings
        t.contains("camera") || t.contains("ক্যামেরা") -> PhoneAction.OpenCamera
        t.contains("calculator") || t == "calc" || t.contains("ক্যালকুলেটর") -> PhoneAction.OpenCalculator
        t == "youtube" || t == "you tube" || t == "ইউটিউব" -> PhoneAction.OpenYouTube
        domainRegex.matches(t) -> PhoneAction.OpenWebsite(t)
        t.split(" ").size <= 3 -> PhoneAction.OpenApp(t)
        else -> null
    }
}

object PhoneActionExecutor {
    private const val YOUTUBE_PACKAGE = "com.google.android.youtube"

    /** Finds an installed launcher app by (partial) name. */
    fun findLaunchIntent(context: Context, label: String): Intent? {
        val pm = context.packageManager
        val q = label.trim().lowercase(Locale.ROOT)
        if (q.length < 2) return null
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0).map {
            it.activityInfo.packageName to it.loadLabel(pm).toString()
        }
        val match = apps.firstOrNull { it.second.equals(q, ignoreCase = true) }
            ?: apps.firstOrNull { it.second.lowercase(Locale.ROOT).startsWith(q) }
            ?: apps.firstOrNull { it.second.lowercase(Locale.ROOT).contains(q) }
        return match?.let { pm.getLaunchIntentForPackage(it.first) }
    }

    /** Runs an already-confirmed action and returns a short message for the chat. */
    fun execute(context: Context, action: PhoneAction): String = try {
        when (action) {
            PhoneAction.OpenSettings -> {
                start(context, Intent(Settings.ACTION_SETTINGS))
                "Opening Settings."
            }
            PhoneAction.OpenCamera -> {
                start(context, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
                "Opening the Camera."
            }
            PhoneAction.OpenCalculator -> {
                start(
                    context,
                    Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR)
                )
                "Opening the Calculator."
            }
            PhoneAction.OpenYouTube -> {
                val view = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
                try {
                    start(context, Intent(view).setPackage(YOUTUBE_PACKAGE))
                } catch (e: ActivityNotFoundException) {
                    start(context, view)
                }
                "Opening YouTube."
            }
            is PhoneAction.SearchYouTube -> {
                val appSearch = Intent(Intent.ACTION_SEARCH)
                    .setPackage(YOUTUBE_PACKAGE)
                    .putExtra("query", action.query)
                try {
                    start(context, appSearch)
                } catch (e: ActivityNotFoundException) {
                    val url = "https://www.youtube.com/results?search_query=" + Uri.encode(action.query)
                    start(context, Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }
                "Searching YouTube for \"${action.query}\"."
            }
            is PhoneAction.OpenWebsite -> {
                val raw = action.url.trim()
                val withScheme =
                    if (raw.startsWith("http://") || raw.startsWith("https://")) raw else "https://$raw"
                val uri = Uri.parse(withScheme)
                if (uri.host.isNullOrBlank()) {
                    "That doesn't look like a valid website address."
                } else {
                    start(context, Intent(Intent.ACTION_VIEW, uri))
                    "Opening ${uri.host}."
                }
            }
            is PhoneAction.OpenApp -> {
                val intent = findLaunchIntent(context, action.label)
                if (intent == null) {
                    "I couldn't find an installed app named \"${action.label}\"."
                } else {
                    start(context, intent)
                    "Opening ${action.label}."
                }
            }
        }
    } catch (e: ActivityNotFoundException) {
        "Sorry, I couldn't find an app on this phone that can do that."
    } catch (e: SecurityException) {
        "Android didn't allow that action."
    }

    private fun start(context: Context, intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }
}
