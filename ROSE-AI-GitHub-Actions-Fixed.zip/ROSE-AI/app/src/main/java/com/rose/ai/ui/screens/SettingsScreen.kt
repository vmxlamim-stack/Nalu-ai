package com.rose.ai.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rose.ai.settings.AppLanguage
import com.rose.ai.settings.AppSettings
import com.rose.ai.ui.MainViewModel
import com.rose.ai.ui.TestState

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = scheme.surfaceVariant.copy(alpha = 0.7f)),
        border = BorderStroke(1.dp, scheme.primary.copy(alpha = 0.3f))
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color = scheme.primary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            content()
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val context = LocalContext.current
    val settings by vm.settings.collectAsState()
    val voices by vm.voice.voices.collectAsState()

    var apiKey by remember { mutableStateOf(settings.apiKey) }
    var model by remember { mutableStateOf(settings.model) }
    var showKey by remember { mutableStateOf(false) }
    var rate by remember { mutableFloatStateOf(settings.speechRate) }
    var showVoiceDialog by remember { mutableStateOf(false) }
    var showClearDialog by remember { mutableStateOf(false) }

    // Fill the fields once DataStore has loaded (only if the user hasn't typed anything yet).
    LaunchedEffect(settings.apiKey) { if (apiKey.isEmpty()) apiKey = settings.apiKey }
    LaunchedEffect(settings.model) { if (model == AppSettings.DEFAULT_MODEL) model = settings.model }
    LaunchedEffect(settings.speechRate) { rate = settings.speechRate }

    val allowedLanguages = when (settings.language) {
        AppLanguage.ENGLISH -> setOf("en")
        AppLanguage.BENGALI -> setOf("bn")
        AppLanguage.AUTO -> setOf("en", "bn")
    }
    val shownVoices = voices.filter { it.languageTag.substringBefore('-') in allowedLanguages }
    val currentVoiceLabel = shownVoices.firstOrNull { it.name == settings.voiceName }?.label
        ?: "Default voice"

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = scheme.primary)
            }
            Text("Settings", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = scheme.onBackground)
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // ---------------- Gemini
            SectionCard("Gemini AI") {
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = {
                        apiKey = it
                        vm.setApiKey(it)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Gemini API key") },
                    singleLine = true,
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = {
                        IconButton(onClick = { showKey = !showKey }) {
                            Icon(
                                if (showKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                contentDescription = if (showKey) "Hide key" else "Show key"
                            )
                        }
                    }
                )
                Text(
                    "Get a free key at aistudio.google.com. It is stored only on this phone.",
                    color = scheme.onSurfaceVariant,
                    fontSize = 12.sp
                )
                OutlinedTextField(
                    value = model,
                    onValueChange = {
                        model = it
                        vm.setModel(it)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Model name") },
                    singleLine = true
                )
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppSettings.SUGGESTED_MODELS.forEach { m ->
                        FilterChip(
                            selected = model.trim() == m,
                            onClick = {
                                model = m
                                vm.setModel(m)
                            },
                            label = { Text(m) }
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = { vm.testConnection(apiKey, model) },
                        enabled = vm.testState !is TestState.Running
                    ) { Text("Test API connection") }
                    if (vm.testState is TestState.Running) {
                        CircularProgressIndicator(
                            modifier = Modifier.padding(start = 12.dp).size(22.dp),
                            strokeWidth = 2.dp
                        )
                    }
                }
                when (val t = vm.testState) {
                    is TestState.Success -> Text(t.message, color = Color(0xFF59E39A), fontSize = 13.sp)
                    is TestState.Failure -> Text(t.message, color = scheme.error, fontSize = 13.sp)
                    else -> Unit
                }
            }

            // ---------------- Language
            SectionCard("Language") {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppLanguage.entries.forEach { lang ->
                        FilterChip(
                            selected = settings.language == lang,
                            onClick = { vm.setLanguage(lang) },
                            label = { Text(lang.label) }
                        )
                    }
                }
                Text(
                    "Used for speech recognition, text-to-speech and ROSE's replies. Auto follows what you write.",
                    color = scheme.onSurfaceVariant,
                    fontSize = 12.sp
                )
            }

            // ---------------- Voice
            SectionCard("Voice") {
                SwitchRow("Speak ROSE's replies", settings.voiceEnabled) { vm.setVoiceEnabled(it) }
                Text("Speech speed: ${"%.1f".format(rate)}x", color = scheme.onSurface)
                Slider(
                    value = rate,
                    onValueChange = { rate = it },
                    onValueChangeFinished = { vm.setSpeechRate(rate) },
                    valueRange = 0.5f..2.0f,
                    steps = 14
                )
                if (shownVoices.isEmpty()) {
                    Text(
                        "No installed voices found for this language. Install voice data in your phone's text-to-speech settings.",
                        color = scheme.onSurfaceVariant,
                        fontSize = 12.sp
                    )
                    OutlinedButton(onClick = {
                        try {
                            context.startActivity(Intent("com.android.settings.TTS_SETTINGS"))
                        } catch (e: Exception) {
                            vm.notify("Open Settings → System → Languages → Text-to-speech.")
                        }
                    }) { Text("Open text-to-speech settings") }
                } else {
                    OutlinedButton(onClick = { showVoiceDialog = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Voice: $currentVoiceLabel", maxLines = 1)
                    }
                    Text(
                        "Android doesn't report voice gender, so voices that are likely female are listed first (★). Use Preview to check.",
                        color = scheme.onSurfaceVariant,
                        fontSize = 12.sp
                    )
                }
                OutlinedButton(onClick = { vm.previewVoice() }) { Text("Preview voice") }
            }

            // ---------------- Appearance
            SectionCard("Appearance") {
                SwitchRow("Dark theme", settings.darkTheme) { vm.setDarkTheme(it) }
            }

            // ---------------- Memory
            SectionCard("Memory (with your consent)") {
                SwitchRow("Let ROSE suggest things to remember", settings.memorySuggestions) {
                    vm.setMemorySuggestions(it)
                }
                Text(
                    "ROSE always asks before saving anything. Saved items stay on this phone.",
                    color = scheme.onSurfaceVariant,
                    fontSize = 12.sp
                )
                if (settings.memories.isEmpty()) {
                    Text("Nothing saved yet.", color = scheme.onSurfaceVariant)
                } else {
                    settings.memories.forEach { m ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("• $m", color = scheme.onSurface, modifier = Modifier.weight(1f))
                            IconButton(onClick = { vm.removeMemory(m) }) {
                                Icon(Icons.Filled.Delete, "Forget this", tint = scheme.error)
                            }
                        }
                    }
                }
            }

            // ---------------- Data
            SectionCard("Data") {
                OutlinedButton(onClick = { showClearDialog = true }) { Text("Clear chat history") }
            }

            // ---------------- About
            SectionCard("About ROSE") {
                Text("ROSE AI 1.0.0", color = scheme.onSurface, fontWeight = FontWeight.SemiBold)
                Text(
                    "ROSE is a friendly AI assistant powered by Google Gemini. She is an AI, not a human, and can make mistakes. " +
                        "Your chats and settings are stored only on this device; messages are sent to the Gemini API to generate replies.",
                    color = scheme.onSurfaceVariant,
                    fontSize = 13.sp
                )
            }
        }
    }

    if (showVoiceDialog) {
        AlertDialog(
            onDismissRequest = { showVoiceDialog = false },
            title = { Text("Choose a voice") },
            text = {
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    item {
                        VoiceRow("Default voice", false, settings.voiceName.isEmpty()) {
                            vm.setVoiceName("")
                            showVoiceDialog = false
                        }
                        HorizontalDivider()
                    }
                    items(shownVoices, key = { it.name }) { v ->
                        VoiceRow(v.label, v.likelyFemale, settings.voiceName == v.name) {
                            vm.setVoiceName(v.name)
                            showVoiceDialog = false
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showVoiceDialog = false }) { Text("Close") } }
        )
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("Clear chat history?") },
            text = { Text("All saved conversations will be deleted from this phone. This can't be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.clearAllHistory()
                    showClearDialog = false
                    vm.notify("Chat history cleared.")
                }) { Text("Clear") }
            },
            dismissButton = { TextButton(onClick = { showClearDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun VoiceRow(label: String, likelyFemale: Boolean, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = null)
        Text(
            text = (if (likelyFemale) "★ " else "") + label,
            modifier = Modifier.padding(start = 8.dp),
            fontSize = 14.sp
        )
    }
}
