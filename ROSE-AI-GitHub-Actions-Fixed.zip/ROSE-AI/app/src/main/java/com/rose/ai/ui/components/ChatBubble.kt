package com.rose.ai.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rose.ai.data.ChatMessage
import com.rose.ai.data.Role
import com.rose.ai.ui.theme.RoseNeon
import com.rose.ai.ui.theme.RosePinkSoft

sealed interface Block {
    data class Text(val text: String) : Block
    data class Code(val lang: String, val code: String) : Block
}

/** Splits a message into prose and fenced code blocks (also handles an unfinished block while streaming). */
fun parseBlocks(text: String): List<Block> {
    val out = mutableListOf<Block>()
    var i = 0
    while (i < text.length) {
        val start = text.indexOf("```", i)
        if (start < 0) {
            out.add(Block.Text(text.substring(i)))
            break
        }
        if (start > i) out.add(Block.Text(text.substring(i, start)))
        val langEnd = text.indexOf('\n', start + 3)
        if (langEnd < 0) break
        val lang = text.substring(start + 3, langEnd).trim()
        val end = text.indexOf("```", langEnd + 1)
        if (end < 0) {
            out.add(Block.Code(lang, text.substring(langEnd + 1).trimEnd()))
            break
        }
        out.add(Block.Code(lang, text.substring(langEnd + 1, end).trimEnd('\n')))
        i = end + 3
    }
    return out.filter { !(it is Block.Text && it.text.isBlank()) }
}

private val inlineRegex = Regex("\\*\\*(.+?)\\*\\*|`([^`\\n]+)`")
private val headingRegex = Regex("^#{1,6}\\s+")

/** Tiny Markdown subset: headings, **bold**, `inline code`, and bullet points. */
fun markdownLite(text: String): AnnotatedString = buildAnnotatedString {
    val lines = text.split("\n")
    lines.forEachIndexed { index, rawLine ->
        var line = rawLine
        var heading = false
        val h = headingRegex.find(line)
        if (h != null) {
            heading = true
            line = line.removeRange(h.range)
        } else if (line.startsWith("* ") || line.startsWith("- ")) {
            line = "•  " + line.drop(2)
        }
        val start = length
        appendInline(line)
        if (heading) {
            addStyle(
                SpanStyle(fontWeight = FontWeight.Bold, fontSize = 17.sp, color = RosePinkSoft),
                start,
                length
            )
        }
        if (index < lines.lastIndex) append("\n")
    }
}

private fun AnnotatedString.Builder.appendInline(line: String) {
    var last = 0
    for (m in inlineRegex.findAll(line)) {
        append(line.substring(last, m.range.first))
        val bold = m.groups[1]?.value
        if (bold != null) {
            withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(bold) }
        } else {
            withStyle(
                SpanStyle(fontFamily = FontFamily.Monospace, background = Color(0x33FF2D95))
            ) { append(m.groups[2]?.value.orEmpty()) }
        }
        last = m.range.last + 1
    }
    append(line.substring(last))
}

@Composable
fun MessageContent(text: String, color: Color) {
    val blocks = remember(text) { parseBlocks(text) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        blocks.forEach { block ->
            when (block) {
                is Block.Text -> Text(
                    text = markdownLite(block.text.trim('\n')),
                    color = color,
                    fontSize = 15.sp,
                    lineHeight = 21.sp
                )
                is Block.Code -> CodeBlock(block.lang, block.code)
            }
        }
    }
}

@Composable
fun ChatBubble(
    message: ChatMessage,
    onSpeak: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val scheme = MaterialTheme.colorScheme
    if (message.role == Role.USER) {
        Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Box(
                Modifier
                    .widthIn(max = 300.dp)
                    .clip(RoundedCornerShape(20.dp, 20.dp, 4.dp, 20.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(RoseNeon.copy(alpha = 0.9f), Color(0xFF8E2DE2).copy(alpha = 0.9f))
                        )
                    )
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text(message.text, color = Color.White, fontSize = 15.sp, lineHeight = 21.sp)
            }
        }
    } else {
        val borderColor = if (message.isError) scheme.error else RoseNeon.copy(alpha = 0.4f)
        Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
            Surface(
                modifier = Modifier.fillMaxWidth(0.96f),
                shape = RoundedCornerShape(20.dp, 20.dp, 20.dp, 4.dp),
                color = scheme.surfaceVariant.copy(alpha = 0.85f),
                border = BorderStroke(1.dp, borderColor)
            ) {
                Column(Modifier.padding(start = 14.dp, end = 6.dp, top = 10.dp, bottom = 2.dp)) {
                    MessageContent(
                        text = message.text,
                        color = if (message.isError) scheme.error else scheme.onSurface
                    )
                    if (!message.isError) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            IconButton(onClick = { onSpeak(message.text) }, modifier = Modifier.size(36.dp)) {
                                Icon(
                                    Icons.Filled.VolumeUp,
                                    contentDescription = "Read aloud",
                                    tint = scheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TypingIndicator(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "typing")
    Row(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f))
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        for (i in 0..2) {
            val a by transition.animateFloat(
                initialValue = 0.25f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    tween(500),
                    RepeatMode.Reverse,
                    initialStartOffset = StartOffset(i * 160)
                ),
                label = "dot$i"
            )
            Box(
                Modifier
                    .size(8.dp)
                    .alpha(a)
                    .clip(CircleShape)
                    .background(RoseNeon)
            )
        }
    }
}
