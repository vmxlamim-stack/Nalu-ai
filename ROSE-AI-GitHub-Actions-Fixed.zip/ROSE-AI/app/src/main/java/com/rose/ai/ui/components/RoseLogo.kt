package com.rose.ai.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rose.ai.ui.theme.NeonViolet
import com.rose.ai.ui.theme.RoseNeon
import com.rose.ai.ui.theme.RosePinkSoft

/** Animated, glowing ROSE wordmark. */
@Composable
fun RoseLogo(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "logo")
    val glow by transition.animateFloat(
        initialValue = 6f,
        targetValue = 26f,
        animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glow"
    )
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Text(
            "ROSE",
            style = TextStyle(
                fontSize = 30.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 6.sp,
                color = RosePinkSoft,
                shadow = Shadow(color = RoseNeon, offset = Offset.Zero, blurRadius = glow)
            )
        )
        Spacer(Modifier.width(6.dp))
        Text(
            "AI",
            style = TextStyle(
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                color = NeonViolet,
                shadow = Shadow(color = NeonViolet, offset = Offset.Zero, blurRadius = glow / 2f)
            )
        )
    }
}
