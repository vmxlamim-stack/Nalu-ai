package com.rose.ai.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.rose.ai.ui.theme.DeepPurple
import com.rose.ai.ui.theme.NeonViolet
import com.rose.ai.ui.theme.RoseNeon
import com.rose.ai.ui.theme.RosePinkSoft
import com.rose.ai.voice.VoiceState
import kotlin.math.PI
import kotlin.math.sin

/** Circular, glowing voice assistant animation. Tap to start/stop listening. */
@Composable
fun VoiceOrb(
    state: VoiceState,
    level: Float,
    thinking: Boolean,
    size: Dp,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "orb")
    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(6000, easing = LinearEasing)),
        label = "rotation"
    )
    val pulse by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Restart),
        label = "pulse"
    )

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val r = this.size.minDimension / 2f
            val wave = (sin(pulse * 2f * PI.toFloat()) + 1f) / 2f
            val energy = when {
                state == VoiceState.LISTENING -> 0.3f + level * 0.7f
                state == VoiceState.SPEAKING -> 0.4f + 0.6f * wave
                thinking -> 0.25f + 0.35f * wave
                else -> 0.12f + 0.08f * wave
            }

            // outer glow
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(RoseNeon.copy(alpha = 0.18f + 0.35f * energy), Color.Transparent),
                    center = c,
                    radius = r
                ),
                radius = r,
                center = c
            )

            // pulsing rings
            for (i in 0..2) {
                val rr = r * (0.55f + 0.1f * i + 0.07f * energy * (i + 1))
                drawCircle(
                    color = RoseNeon.copy(alpha = (0.55f - 0.15f * i).coerceAtLeast(0.1f)),
                    radius = rr,
                    center = c,
                    style = Stroke(width = 2.dp.toPx())
                )
            }

            // rotating neon arc
            rotate(rotation, c) {
                drawArc(
                    brush = Brush.sweepGradient(
                        listOf(Color.Transparent, RoseNeon, NeonViolet, Color.Transparent),
                        center = c
                    ),
                    startAngle = 0f,
                    sweepAngle = 300f,
                    useCenter = false,
                    topLeft = Offset(c.x - r * 0.74f, c.y - r * 0.74f),
                    size = Size(r * 1.48f, r * 1.48f),
                    style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            // glowing core
            val coreR = r * 0.42f * (1f + 0.12f * energy)
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(RosePinkSoft, RoseNeon, DeepPurple),
                    center = c,
                    radius = coreR
                ),
                radius = coreR,
                center = c
            )
        }
        Icon(
            imageVector = if (state == VoiceState.LISTENING) Icons.Filled.Stop else Icons.Filled.Mic,
            contentDescription = if (state == VoiceState.LISTENING) "Stop listening" else "Start listening",
            tint = Color.White,
            modifier = Modifier.size(size * 0.18f)
        )
    }
}
