package com.rose.ai.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rose.ai.ui.theme.NeonViolet
import com.rose.ai.ui.theme.RoseNeon
import kotlinx.coroutines.delay

private val CodeDefault = Color(0xFFE8DDF5)
private val CodeComment = Color(0xFF8A7A9E)
private val CodeString = Color(0xFF9AE6B4)
private val CodeNumber = Color(0xFFFFC66D)
private val CodeKeyword = Color(0xFFFF79C6)
private val CodeTag = Color(0xFF8BE9FD)

/** Lightweight regex-based syntax highlighter (Python, Kotlin, Java, JS, HTML, CSS, ...). */
object SyntaxHighlighter {
    private val keywords = listOf(
        "def", "class", "return", "if", "else", "elif", "for", "while", "import", "from", "as", "in", "is",
        "not", "and", "or", "None", "True", "False", "val", "var", "fun", "when", "object", "interface",
        "override", "private", "public", "protected", "const", "let", "function", "new", "this", "try",
        "catch", "except", "finally", "throw", "raise", "with", "lambda", "yield", "async", "await", "null",
        "true", "false", "undefined", "typeof", "package", "static", "void", "int", "String", "break",
        "continue", "pass", "self", "super", "extends", "implements", "export", "default", "switch", "case",
        "do", "sealed", "enum", "suspend", "companion", "internal", "abstract", "final", "instanceof",
        "global", "del", "assert", "println"
    ).joinToString("|")

    private const val TRIPLE = "\"\"\"[\\s\\S]*?\"\"\""
    private const val DOUBLE = "\"(?:\\\\.|[^\"\\\\\\n])*\""
    private const val SINGLE = "'(?:\\\\.|[^'\\\\\\n])*'"
    private const val BACKTICK = "`[^`]*`"
    private const val BLOCK_COMMENT = "/\\*[\\s\\S]*?\\*/|<!--[\\s\\S]*?-->"

    private fun build(hashComments: Boolean): Regex {
        val line = if (hashComments) "#[^\\n]*" else "//[^\\n]*"
        val pattern = "($BLOCK_COMMENT|$line)|($TRIPLE|$DOUBLE|$SINGLE|$BACKTICK)" +
            "|(</?[A-Za-z][\\w-]*)|(\\b\\d+(?:\\.\\d+)?\\b)|(\\b(?:$keywords)\\b)"
        return Regex(pattern)
    }

    private val slashRegex = build(false)
    private val hashRegex = build(true)
    private val hashLanguages = setOf("python", "py", "bash", "sh", "shell", "yaml", "yml", "ruby", "rb")

    fun highlight(code: String, language: String): AnnotatedString {
        val regex = if (language.lowercase() in hashLanguages) hashRegex else slashRegex
        return buildAnnotatedString {
            var last = 0
            for (m in regex.findAll(code)) {
                if (m.range.first > last) append(code.substring(last, m.range.first))
                val color = when {
                    m.groups[1] != null -> CodeComment
                    m.groups[2] != null -> CodeString
                    m.groups[3] != null -> CodeTag
                    m.groups[4] != null -> CodeNumber
                    else -> CodeKeyword
                }
                withStyle(SpanStyle(color = color)) { append(m.value) }
                last = m.range.last + 1
            }
            if (last < code.length) append(code.substring(last))
        }
    }
}

/** Syntax-highlighted code block with a copy-to-clipboard button. */
@Composable
fun CodeBlock(language: String, code: String, modifier: Modifier = Modifier) {
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            delay(1500)
            copied = false
        }
    }
    val highlighted = remember(code, language) { SyntaxHighlighter.highlight(code, language) }
    val shape = RoundedCornerShape(12.dp)

    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Color(0xFF0B0614))
            .border(1.dp, RoseNeon.copy(alpha = 0.35f), shape)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(Color(0xFF1B0F2E))
                .padding(start = 12.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = language.ifBlank { "code" },
                color = NeonViolet,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = {
                clipboard.setText(AnnotatedString(code))
                copied = true
            }) {
                Icon(
                    imageVector = if (copied) Icons.Filled.Check else Icons.Filled.ContentCopy,
                    contentDescription = "Copy code",
                    modifier = Modifier.size(16.dp),
                    tint = RoseNeon
                )
                Spacer(Modifier.width(6.dp))
                Text(if (copied) "Copied" else "Copy", fontSize = 12.sp, color = RoseNeon)
            }
        }
        Column(Modifier.horizontalScroll(rememberScrollState()).padding(12.dp)) {
            Text(
                text = highlighted,
                color = CodeDefault,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                lineHeight = 18.sp,
                softWrap = false
            )
        }
    }
}
