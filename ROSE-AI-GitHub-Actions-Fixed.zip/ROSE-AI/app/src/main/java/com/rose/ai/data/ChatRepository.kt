package com.rose.ai.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Stores chat history locally as JSON in the app's private storage. */
class ChatRepository(context: Context) {
    private val file = File(context.filesDir, "conversations.json")
    private val tmp = File(context.filesDir, "conversations.json.tmp")
    private val mutex = Mutex()

    suspend fun load(): List<Conversation> = withContext(Dispatchers.IO) {
        mutex.withLock {
            try {
                if (!file.exists()) {
                    emptyList<Conversation>()
                } else {
                    val arr = JSONArray(file.readText())
                    (0 until arr.length()).map { parseConversation(arr.getJSONObject(it)) }
                }
            } catch (e: Exception) {
                emptyList<Conversation>()
            }
        }
    }

    suspend fun save(list: List<Conversation>) {
        withContext(Dispatchers.IO) {
            mutex.withLock {
                try {
                    val arr = JSONArray()
                    list.forEach { arr.put(toJson(it)) }
                    tmp.writeText(arr.toString())
                    if (!tmp.renameTo(file)) {
                        file.delete()
                        tmp.renameTo(file)
                    }
                } catch (e: Exception) {
                    // Saving history is best-effort.
                }
            }
        }
    }

    private fun toJson(c: Conversation): JSONObject = JSONObject().apply {
        put("id", c.id)
        put("title", c.title)
        put("updatedAt", c.updatedAt)
        put("messages", JSONArray().apply {
            c.messages.forEach { m ->
                put(JSONObject().apply {
                    put("id", m.id)
                    put("role", m.role.name)
                    put("text", m.text)
                    put("timestamp", m.timestamp)
                    put("isError", m.isError)
                })
            }
        })
    }

    private fun parseConversation(o: JSONObject): Conversation {
        val arr = o.optJSONArray("messages") ?: JSONArray()
        val messages = (0 until arr.length()).map { i ->
            val m = arr.getJSONObject(i)
            ChatMessage(
                id = m.optString("id"),
                role = runCatching { Role.valueOf(m.optString("role")) }.getOrDefault(Role.ROSE),
                text = m.optString("text"),
                timestamp = m.optLong("timestamp"),
                isError = m.optBoolean("isError", false)
            )
        }
        return Conversation(
            id = o.getString("id"),
            title = o.optString("title", "New chat"),
            updatedAt = o.optLong("updatedAt"),
            messages = messages
        )
    }
}
