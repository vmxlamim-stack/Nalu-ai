package com.rose.ai.ui

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rose.ai.actions.PhoneAction
import com.rose.ai.actions.PhoneActionExecutor
import com.rose.ai.actions.PhoneActionParser
import com.rose.ai.ai.GeminiClient
import com.rose.ai.ai.GeminiException
import com.rose.ai.ai.RosePersona
import com.rose.ai.data.ChatMessage
import com.rose.ai.data.ChatRepository
import com.rose.ai.data.Conversation
import com.rose.ai.data.Role
import com.rose.ai.settings.AppLanguage
import com.rose.ai.settings.AppSettings
import com.rose.ai.settings.SettingsStore
import com.rose.ai.voice.VoiceController
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.UUID

sealed interface TestState {
    object Idle : TestState
    object Running : TestState
    data class Success(val message: String) : TestState
    data class Failure(val message: String) : TestState
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val store = SettingsStore(application)
    private val repo = ChatRepository(application)
    val voice = VoiceController(application)

    val settings: StateFlow<AppSettings> =
        store.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    var conversations by mutableStateOf<List<Conversation>>(listOf(Conversation()))
        private set
    var currentId by mutableStateOf(conversations.first().id)
        private set
    var isLoading by mutableStateOf(false)
        private set
    var isStreaming by mutableStateOf(false)
        private set
    var codingMode by mutableStateOf(false)
    var pendingAction by mutableStateOf<PhoneAction?>(null)
        private set
    var pendingMemory by mutableStateOf<String?>(null)
        private set
    var testState by mutableStateOf<TestState>(TestState.Idle)
        private set

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val events: SharedFlow<String> = _events.asSharedFlow()

    private var streamJob: Job? = null

    val messages: List<ChatMessage>
        get() = conversations.firstOrNull { it.id == currentId }?.messages.orEmpty()

    init {
        voice.onFinalResult = { text -> send(text) }
        viewModelScope.launch { voice.events.collect { _events.tryEmit(it) } }
        viewModelScope.launch {
            val loaded = repo.load()
            val existing = conversations.map { it.id }.toSet()
            conversations = conversations + loaded.filter { it.id !in existing }
        }
    }

    // ------------------------------------------------------------ chat

    fun send(input: String) {
        val text = input.trim()
        if (text.isEmpty() || isStreaming) return
        voice.stopSpeaking()
        val convId = currentId
        addMessage(convId, ChatMessage(role = Role.USER, text = text))

        // 1) Local phone commands (always ask for confirmation first).
        if (!codingMode) {
            val action = PhoneActionParser.parse(text)
            if (action != null && isActionAvailable(action)) {
                pendingAction = action
                addMessage(
                    convId,
                    ChatMessage(role = Role.ROSE, text = "Sure! Please confirm: ${action.describe()}.")
                )
                persist()
                return
            }
        }

        // 2) Ask Gemini.
        val s = settings.value
        if (s.apiKey.isBlank()) {
            addMessage(
                convId,
                ChatMessage(
                    role = Role.ROSE,
                    text = "Please add your Gemini API key first: open Settings → Gemini API key.",
                    isError = true
                )
            )
            persist()
            return
        }

        val history = conversations.firstOrNull { it.id == convId }?.messages.orEmpty()
            .filter { !it.isError }
            .map { (if (it.role == Role.USER) "user" else "model") to it.text }
        val system = RosePersona.systemPrompt(s.memories, codingMode, s.memorySuggestions, s.language)
        val replyId = UUID.randomUUID().toString()

        isStreaming = true
        isLoading = true
        streamJob = viewModelScope.launch {
            val raw = StringBuilder()
            var created = false
            try {
                GeminiClient.stream(s.apiKey, s.model, system, history).collect { chunk ->
                    raw.append(chunk)
                    val shown = RosePersona.cleanForDisplay(raw.toString())
                    if (!created) {
                        created = true
                        isLoading = false
                        addMessage(convId, ChatMessage(id = replyId, role = Role.ROSE, text = shown))
                    } else {
                        replaceText(convId, replyId, shown)
                    }
                }
                val (clean, memory) = RosePersona.extractMemory(raw.toString())
                if (!created || clean.isBlank()) {
                    addMessage(
                        convId,
                        ChatMessage(
                            role = Role.ROSE,
                            text = "ROSE got an empty response. Try again, or check the model name in Settings.",
                            isError = true
                        )
                    )
                } else {
                    replaceText(convId, replyId, clean)
                    if (memory != null && s.memorySuggestions && memory !in s.memories) {
                        pendingMemory = memory
                    }
                    if (s.voiceEnabled) {
                        voice.speak(clean, s.language, s.speechRate, s.voiceName)
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                addMessage(
                    convId,
                    ChatMessage(role = Role.ROSE, text = friendly(e), isError = true)
                )
            } finally {
                isLoading = false
                isStreaming = false
                persist()
            }
        }
    }

    fun stopGeneration() {
        streamJob?.cancel()
    }

    private fun isActionAvailable(action: PhoneAction): Boolean =
        action !is PhoneAction.OpenApp ||
            PhoneActionExecutor.findLaunchIntent(getApplication<Application>(), action.label) != null

    private fun friendly(e: Throwable): String = when (e) {
        is GeminiException -> e.message ?: "Gemini returned an error."
        is UnknownHostException, is ConnectException -> "No internet connection. Please check your network."
        is SocketTimeoutException -> "The request timed out. Please try again."
        is IOException -> "Network error: ${e.message}"
        else -> e.message ?: "Something went wrong."
    }

    // ------------------------------------------------------------ conversations

    private fun updateConversation(id: String, transform: (Conversation) -> Conversation) {
        conversations = conversations.map { if (it.id == id) transform(it) else it }
    }

    private fun addMessage(convId: String, message: ChatMessage) {
        updateConversation(convId) { c ->
            val title = if (c.messages.isEmpty() && message.role == Role.USER) {
                message.text.lineSequence().first().take(40)
            } else c.title
            c.copy(
                title = title,
                messages = c.messages + message,
                updatedAt = System.currentTimeMillis()
            )
        }
    }

    private fun replaceText(convId: String, messageId: String, text: String) {
        updateConversation(convId) { c ->
            c.copy(messages = c.messages.map { if (it.id == messageId) it.copy(text = text) else it })
        }
    }

    private fun persist() {
        val snapshot = conversations.filter { it.messages.isNotEmpty() }
        viewModelScope.launch { repo.save(snapshot) }
    }

    private fun cancelStreaming() {
        streamJob?.cancel()
        isStreaming = false
        isLoading = false
    }

    fun newChat() {
        cancelStreaming()
        voice.stopSpeaking()
        val empty = conversations.firstOrNull { it.messages.isEmpty() }
        if (empty != null) {
            currentId = empty.id
        } else {
            val c = Conversation()
            conversations = conversations + c
            currentId = c.id
        }
    }

    fun openConversation(id: String) {
        cancelStreaming()
        voice.stopSpeaking()
        currentId = id
    }

    fun deleteConversation(id: String) {
        conversations = conversations.filter { it.id != id }
        if (id == currentId) {
            cancelStreaming()
            newChat()
        }
        persist()
    }

    fun clearAllHistory() {
        cancelStreaming()
        voice.stopSpeaking()
        val c = Conversation()
        conversations = listOf(c)
        currentId = c.id
        persist()
    }

    // ------------------------------------------------------------ phone actions + memory

    fun confirmAction(context: Context) {
        val action = pendingAction ?: return
        pendingAction = null
        val result = PhoneActionExecutor.execute(context, action)
        addMessage(currentId, ChatMessage(role = Role.ROSE, text = result))
        persist()
    }

    fun dismissAction() {
        if (pendingAction == null) return
        pendingAction = null
        addMessage(currentId, ChatMessage(role = Role.ROSE, text = "Okay, cancelled."))
        persist()
    }

    fun acceptMemory() {
        val m = pendingMemory ?: return
        pendingMemory = null
        viewModelScope.launch { store.addMemory(m) }
    }

    fun declineMemory() {
        pendingMemory = null
    }

    fun removeMemory(text: String) {
        viewModelScope.launch { store.removeMemory(text) }
    }

    // ------------------------------------------------------------ voice

    fun startListening() = voice.startListening(settings.value.language)

    fun stopListening() = voice.stopListening()

    fun speak(text: String) {
        val s = settings.value
        voice.speak(text, s.language, s.speechRate, s.voiceName)
    }

    fun previewVoice() {
        val s = settings.value
        val sample = if (s.language == AppLanguage.BENGALI) {
            "হ্যালো, আমি রোজ। আমি আপনাকে কীভাবে সাহায্য করতে পারি?"
        } else {
            "Hello, I'm ROSE, your AI assistant. How can I help you today?"
        }
        voice.speak(sample, s.language, s.speechRate, s.voiceName)
    }

    fun notify(message: String) {
        _events.tryEmit(message)
    }

    // ------------------------------------------------------------ settings

    fun setApiKey(v: String) { viewModelScope.launch { store.setApiKey(v) } }
    fun setModel(v: String) { viewModelScope.launch { store.setModel(v) } }
    fun setLanguage(v: AppLanguage) { viewModelScope.launch { store.setLanguage(v) } }
    fun setVoiceEnabled(v: Boolean) {
        viewModelScope.launch { store.setVoiceEnabled(v) }
        if (!v) voice.stopSpeaking()
    }
    fun setSpeechRate(v: Float) { viewModelScope.launch { store.setSpeechRate(v) } }
    fun setVoiceName(v: String) { viewModelScope.launch { store.setVoiceName(v) } }
    fun setDarkTheme(v: Boolean) { viewModelScope.launch { store.setDarkTheme(v) } }
    fun setMemorySuggestions(v: Boolean) { viewModelScope.launch { store.setMemorySuggestions(v) } }

    fun testConnection(apiKey: String, model: String) {
        viewModelScope.launch {
            testState = TestState.Running
            store.setApiKey(apiKey)
            store.setModel(model)
            val result = GeminiClient.testConnection(apiKey, model)
            testState = result.fold(
                onSuccess = { TestState.Success("Connected to ${model.trim()} ✓  (reply: $it)") },
                onFailure = { TestState.Failure(friendly(it)) }
            )
        }
    }

    override fun onCleared() {
        voice.release()
        super.onCleared()
    }
}
