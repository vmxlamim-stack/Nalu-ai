# ROSE AI 🌹 — Android Personal AI Assistant

A native Android app (Kotlin + Jetpack Compose + Material 3) with a friendly female AI persona powered by the **Gemini API**.
ROSE understands **Bengali, Banglish and English**, talks (speech-to-text + text-to-speech), helps with coding, and can open
a few apps/websites on your phone — always after you confirm.

> ⚠️ **Build status:** this project was written without access to the Android SDK or the internet, so it has **not been
> compiled or run yet**. Dependency versions are pinned to a known-compatible set (below). If Android Studio reports a
> compile error on first sync, please treat it as a bug to fix — most likely a one-line import/API tweak.

## Requirements
- Android Studio Koala (2024.1) or newer, with **JDK 17** (bundled) and **Android SDK 34**
- Device/emulator with Android 8.0+ (API 26+). Tested target: Android 10–14.
- A Gemini API key from <https://aistudio.google.com/apikey> (Gemini 4 Argon requires paid API access; Gemini 3.8 Flash is the suggested alternative if you do not have paid access).

## Build & run
**Android Studio (recommended):** `File → Open` this folder → wait for Gradle sync → Run ▶.

**Command line:**
```bash
./gradlew assembleDebug        # Windows: gradlew.bat assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```
`gradle/wrapper/gradle-wrapper.jar` is a binary that could not be bundled. `./gradlew` regenerates it automatically if you
have Gradle installed (`gradle wrapper --gradle-version 8.7`). Android Studio does not need it.
Create `local.properties` with `sdk.dir=/path/to/Android/sdk` if building outside Android Studio.

Pinned versions: Gradle 8.7 · AGP 8.5.2 · Kotlin 1.9.24 · Compose compiler 1.5.14 · Compose BOM 2024.06.00 ·
compileSdk/targetSdk 34 · minSdk 26.

## First launch
1. Open **Settings** (gear icon) → paste your **Gemini API key**.
2. The default model is `gemini-3.8-flash`. You can choose `gemini-3.5-flash-lite` for a lighter model, or `gemini-4-argon` if your API account has paid access → **Test API connection**.
3. Chat by typing, or tap the glowing orb / mic to talk.

## Features
| Area | What it does |
|---|---|
| Gemini brain | REST client for `generativelanguage.googleapis.com/v1beta`, **streaming** (SSE), configurable key + model, test button, friendly errors, loading animation. Key lives in local DataStore only — never in code. |
| Persona | Warm female assistant, Bengali / Banglish / English, always says it's an AI. |
| Voice | `SpeechRecognizer` (live partial text), `TextToSpeech`, start/stop buttons, speed slider, voice on/off, bn-BD / en-US, voice picker from installed TTS voices. |
| Phone actions | Settings, Camera, Calculator, installed apps, YouTube, YouTube search, websites. Every action shows a confirmation dialog. No messaging, purchases or deletion. |
| Coding mode | Python / HTML-CSS-JS / Kotlin generation, explain, debug, format; syntax-highlighted blocks with **Copy**. |
| Memory | ROSE may *propose* remembering a preference; it is saved only if you tap **Remember**. View/delete in Settings. |
| History | Multiple saved chats (local JSON), open/delete, clear all. |
| Theme | Black/dark-purple with rose-pink neon; dark/light switch. |

### Example commands
`open camera` · `open settings` · `open calculator` · `open youtube` · `search youtube for lo-fi music` ·
`open whatsapp` · `open github.com` · `youtube e gaan search koro` · `ক্যামেরা খোলো`

## Voice notes
- Android has **no API for voice gender**. The picker lists installed voices (likely-female ones first, marked ★, based on
  voice names such as Google's `-x-sfg`/`-x-iob`). Use **Preview voice** to check. For Bengali, install voice data in
  *Phone Settings → Text-to-speech*.
- Speech recognition may need internet depending on the device's recognizer.

## Permissions
Only `INTERNET` and `RECORD_AUDIO` (asked at runtime, when you first use the mic). No notification, contacts, location,
or storage permissions.

## Privacy & security
- Chats, memories and settings stay on the device. Messages are sent to Google's Gemini API to generate replies.
- The API key is stored in app-private DataStore (not encrypted at rest) and sent via the `x-goog-api-key` header.
- `allowBackup=false`, HTTPS only.

## Project structure
```
ROSE-AI/
├─ build.gradle.kts · settings.gradle.kts · gradle.properties · gradlew(.bat) · gradle/wrapper/
└─ app/
   ├─ build.gradle.kts · proguard-rules.pro
   └─ src/main/
      ├─ AndroidManifest.xml
      ├─ res/ (values, adaptive launcher icon)
      └─ java/com/rose/ai/
         ├─ MainActivity.kt          navigation host + confirmation dialogs
         ├─ ai/       GeminiClient.kt (REST + streaming) · RosePersona.kt (system prompt, memory tag)
         ├─ voice/    VoiceController.kt (STT + TTS)
         ├─ actions/  PhoneActions.kt (command parser + safe intents)
         ├─ settings/ SettingsStore.kt (DataStore)
         ├─ data/     Models.kt · ChatRepository.kt
         └─ ui/       MainViewModel.kt · theme/ · components/ (logo, orb, bubbles, code block, input) · screens/
```

## Changing the Gemini model
Settings → *Model name* (e.g. `gemini-3.8-flash`). The name is inserted into
`.../v1beta/models/<name>:streamGenerateContent`. Model availability depends on your API key.

## Troubleshooting
- **400/403 errors:** wrong key or model name → use *Test API connection*.
- **429:** free-tier quota; wait or switch to a lighter model.
- **No Bengali speech:** install Bengali voice data for your TTS engine.
- **"Open app" not found:** the app name must match its launcher label.

## Build on GitHub Actions
A workflow is included at `.github/workflows/android-build.yml`.

1. Upload this project to a GitHub repository (the folder containing `settings.gradle.kts` must be the repository root).
2. Open the repository's **Actions** tab.
3. Select **Build ROSE AI APK** and click **Run workflow**, or push to `main` / `master`.
4. When the workflow finishes, open the successful run and find **Artifacts** at the bottom.
5. Download **ROSE-AI-debug-apk**. Inside it is `app-debug.apk`.

The workflow detects whether the project files are in the repository root or in a `ROSE-AI/` subfolder, installs JDK 17, Android SDK and Gradle 8.7, then builds the APK. It does not need your Gemini API key to compile the APK. Add your API key inside the app's Settings after installing it.

**Model billing note:** `gemini-3.8-flash` is the default stable general-use model. `gemini-4-argon` is a higher-end model and is not available on the free API tier. Model availability and pricing can change; check Google’s official model list before switching. Model access and pricing can change; check Google's official model list before switching.
