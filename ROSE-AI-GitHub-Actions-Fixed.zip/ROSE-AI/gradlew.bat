@echo off
rem ROSE AI Gradle launcher (Windows).
set APP_HOME=%~dp0
set JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
if not exist "%JAR%" (
  where gradle >nul 2>nul
  if errorlevel 1 (
    echo gradle-wrapper.jar is missing and no local Gradle was found.
    echo Fix: open this folder in Android Studio, or install Gradle 8.7 and run: gradle wrapper
    exit /b 1
  )
  pushd "%APP_HOME%"
  call gradle wrapper --gradle-version 8.7
  popd
)
if defined JAVA_HOME (set JAVACMD=%JAVA_HOME%\bin\java.exe) else (set JAVACMD=java.exe)
"%JAVACMD%" -Xmx64m -Xms64m -classpath "%JAR%" org.gradle.wrapper.GradleWrapperMain %*
